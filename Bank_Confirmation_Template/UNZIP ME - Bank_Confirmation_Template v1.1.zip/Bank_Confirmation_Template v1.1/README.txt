Excel - Bank Confirmation_v1.0.xlsm -> File contains the bank confirmation template which should be filled out by the PwC personnel
Templates Folder -> Contains the bank confirmation template for UAE, DIFC and ADGM 
Confirmation Folder -> Contains the bank confirmations created from the excel file. It uses the templates in the templates folder to create the bank confirmations

Please do not delete any folders or files. You can delete all the bank confirmations in the "Confirmations" folder that have been generated. Do not delete any templates or the excel files